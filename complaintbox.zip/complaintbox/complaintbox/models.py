from django.db import models

class studentregister(models.Model):
    userphoto=models.CharField(max_length=500)
    useremail=models.CharField(max_length=500)
    username=models.CharField(max_length=500)
    userphone=models.CharField(max_length=500)
    password=models.CharField(max_length=500)

class facultyregister(models.Model):
    designation=models.CharField(max_length=500)
    name=models.CharField(max_length=500)
    email=models.CharField(max_length=500)
    password=models.CharField(max_length=500)

class facack(models.Model):
    date=models.CharField(max_length=500)
    designation=models.CharField(max_length=500)
    name=models.CharField(max_length=500)
    email=models.CharField(max_length=500)
    ackmesg=models.CharField(max_length=500)

class complaint(models.Model):
    userid=models.CharField(max_length=500)
    complaintto=models.CharField(max_length=500)
    date=models.CharField(max_length=500)
    name=models.CharField(max_length=500)
    email=models.CharField(max_length=500)
    complaintmesg=models.CharField(max_length=5000)
    status=models.CharField(max_length=500)
    user_id=models.IntegerField(max_length=10)

class acknowledgement(models.Model):
    name=models.CharField(max_length=500)
    date=models.CharField(max_length=500)
    email=models.CharField(max_length=500)
    fromemail=models.CharField(max_length=200)
    ackmesg=models.CharField(max_length=500)