from django.http import HttpResponse
from django.shortcuts import render
from django.shortcuts import redirect
from  django.core.files.storage import FileSystemStorage
from django.conf import settings
from .models import*


def index(request):
    return render(request,'index.html')

def student_register(request):
    return render(request,'student_register.html')

def studentaddregister(request):
    if request.method=="POST":
        photos=request.FILES['photo']
        fs=FileSystemStorage()
        filename=fs.save(photos.name,photos)
        mailid=request.POST.get('email')
        fullname=request.POST.get('name')
        phoneno=request.POST.get('phone')
        passwords=request.POST.get('password')
        regestration=studentregister(userphoto=photos,useremail=mailid,username=fullname,userphone=phoneno,password=passwords)
        regestration.save()
    return render(request,'student_register.html',{'sucess':'RegisteredSusessfully'})

def faculty_register(request):
    return render(request,'faculty_register.html')

def facultyaddregister(request):
    if request.method=="POST":
        designation=request.POST.get('designation')
        fullname=request.POST.get('name')
        mailid=request.POST.get('email')
        passwords=request.POST.get('password')
        regestration=facultyregister(designation=designation,email=mailid,name=fullname,password=passwords)
        regestration.save()
    return render(request,'faculty_register.html',{'sucess':'RegisteredSusessfully'})

def viewstudent(request):
    return render(request,'viewstudent.html')

def viewstudent(request):
    user=studentregister.objects.all()
    return render(request,'viewstudent.html',{'result':user})

def viewfaculty(request):
    return render(request,'viewfaculty.html')

def viewfaculty(request):
    user=facultyregister.objects.all()
    return render(request,'viewfaculty.html',{'result':user})

def login(request):
    return render(request,'login.html')

def login(request):
    email = request.POST.get('email')
    password = request.POST.get('password')
    if email == 'admin123@gmail.com' and password =='admin@123':
        request.session['logintdetail'] = email
        request.session['admin'] = 'admin'
        return render(request, 'index.html')

    elif studentregister.objects.filter(useremail=email,password=password).exists():
        s=studentregister.objects.get(useremail=request.POST['email'], password=password)
        if s.password == request.POST['password']:
            request.session['uid'] = s.id
            request.session['uname'] = s.username

            request.session['email'] = email

            request.session['user'] = 'user'

            return render(request,'index.html')
    elif facultyregister.objects.filter(email=email,password=password).exists():
        f=facultyregister.objects.get(email=request.POST['email'], password=password)
        if f.password == request.POST['password']:
            request.session['vid'] = f.id
            request.session['uname'] = f.name

            request.session['email'] = email

            request.session['user'] = 'user'

            return render(request,'index.html')
    else:
        return render(request, 'login.html', {'status': 'Invalid Username or Password'})
    
def logout(request):
    session_keys = list(request.session.keys())
    for key in session_keys:
        del request.session[key]
    return redirect(index)

def complaintstd(request):
    return render(request,'complaintstd.html')

def complaintstd(request):
    b=request.session['uid']
    if request.method=="POST":
        userid=request.POST.get('userid')
        complaintto=request.POST.get('complaintto')
        date=request.POST.get('date')
        name=request.POST.get('name')
        email=request.POST.get('email')
        complaintmesg=request.POST.get('complaintmesg')
        status=request.POST.get('status')
        regestration=complaint(userid=userid,complaintto=complaintto,date=date,name=name,email=email,complaintmesg=complaintmesg,status=status,user_id=b)
        regestration.save()
    return render(request,'complaintstd.html',{'sucess':'RegisteredSusessfully'})

def complaintview(request):
    return render(request,'complaintview.html')

def complaintview(request):
    temp=request.session['uid']
    user=complaint.objects.filter(user_id=temp)
    return render(request,'complaintview.html',{'result':user})

def complaintviewa(request):
    return render(request,'complaintviewa.html')

def complaintviewa(request):
    user=complaint.objects.all()
    return render(request,'complaintviewa.html',{'result':user})

def complaintviewf(request):
    return render(request,'complaintviewf.html')

def complaintviewf(request):
    temp=request.session['email']
    user=complaint.objects.filter(complaintto=temp)
    return render(request,'complaintviewf.html',{'result':user})




def acknowledgementfly(request):
    return render(request,'acknowledgementfly.html')

def knowledgefly(request):
    user=complaint.objects.all()
    return render(request,'acknowledgementview.html',{'result':user})

def knowledgefly(request):
    saver=complaint.objects.all()
    return render(request,'acknowledgementview.html',{'result':saver})


def delete(request,id):
    member=complaint.objects.get(id=id)
    member.delete()
    return redirect(knowledgefly)

# def updates(request,id): 
#     upt=complaint.objects.get(id=id)
#     return render(request,'acknowledgementview.html',{'result':upt})

# def updatess(request,id):
#     if request.method=="POST":
#        userid=request.POST.get('userid')
#        complaintto=request.POST.get('complaintto')
#        date=request.POST.get('date')
#        name=request.POST.get('name')
#        email=request.POST.get('email')
#        complaintmesg=request.POST.get('complaintmesg')
#        status=request.POST.get('status')
#        regestration=complaint(userid=userid,complaintto=complaintto,date=date,name=name,email=email,status=status,id=id)
#        regestration.save()
#     return redirect(acknowledgementfly)
    
def acknowledgementtofly(request):
    return render(request,'acknowledgementtofly.html')

def knowledgetofly(request):
    if request.method=="POST":
        designation=request.POST.get('designation')
        fullname=request.POST.get('name')
        mailid=request.POST.get('email')
        passwords=request.POST.get('password')
        regestration=facultyregister(designation=designation,email=mailid,name=fullname,password=passwords)
        regestration.save()
    return render(request,'faculty_register.html',{'sucess':'RegisteredSusessfully'})

# def knowledgetostd(request):
#     return render(request,'acknowledgementtostd.html')

# def acktostd(request):
#     if request.method=="POST":
#         name=request.POST.get('name')
#         date=request.POST.get('date')
#         email=request.POST.get('email')
#         ackmesg=request.POST.get('ackmesg')
#         regestration=acknowledgement(date=date,name=name,email=email,ackmesg=ackmesg)
#         regestration.save()
#     return render(request,'acknowledgementtostd.html',{'sucess':'RegisteredSusessfully'})

def viewstdknowledge(request):
    return render(request,'viewstdknowledge.html')

def viewstdknowledge(request):
    temp=request.session['email']
    user=acknowledgement.objects.filter(fromemail=temp)
    return render(request,'viewstdknowledge.html',{'result':user})

def viewstdknowledges(request):
    return render(request,'viewstdknowledges.html')

def viewstdknowledges(request):
    temp=request.session['email']
    user=acknowledgement.objects.filter(email=temp)
    return render(request,'viewstdknowledge.html',{'result':user})

def admintofly(request):
    return render(request,'acknowledgementtofly.html')

def acktofly(request):
    if request.method=="POST":
        date=request.POST.get('date')
        designation=request.POST.get('designation')
        email=request.POST.get('email')
        ackmesg=request.POST.get('ackmesg')
        regestration=facack(date=date,designation=designation,email=email,ackmesg=ackmesg)
        regestration.save()
    return render(request,'acknowledgementtofly.html',{'sucess':'RegisteredSusessfully'})

def viewflyknowledge(request):
    return render(request,'viewflyknowledge.html')

def viewflyknowledge(request):
    temp=request.session['email']
    user=facack.objects.filter(email=temp)
    return render(request,'viewflyknowledge.html',{'result':user})

def viewflyknowledgea(request):
    return render(request,'viewflyknowledge.html')

def viewflyknowledgea(request):
    user=facack.objects.all()
    return render(request,'viewflyknowledge.html',{'result':user})


def delstd(request):
    return render(request,"delstd.html")

def delstd(request):
    user=studentregister.objects.all()
    return render(request,"delstd.html",{'result':user})



def deletes(request,id):
    member=studentregister.objects.get(id=id)
    member.delete()
    return redirect(delstd)


def stdedit(request):
    return render(request,'stdedit.html')

def stdedit(request):
    user=studentregister.objects.all()
    return render(request,'stdedit.html',{'result':user})

def editstdform(request):
    saver=studentregister.objects.all()
    return render(request,'editstdform.html',{'result':saver})

def updatea(request,id):
    user=studentregister.objects.get(id=id)
    return render(request,'editstdform.html',{'result':user})

def updatesa(request,id):
    if request.method=="POST":
        photos=request.FILES['photo']
        fs=FileSystemStorage()
        filename=fs.save(photos.name,photos)
        mailid=request.POST.get('email')
        fullname=request.POST.get('name')
        phoneno=request.POST.get('phone')
        passwords=request.POST.get('password')
        regestration=studentregister(userphoto=photos,useremail=mailid,username=fullname,userphone=phoneno,password=passwords,id=id)
        regestration.save()
    return redirect(editstdform)
    



def delfly(request):
    return render(request,"delfly.html")

def delfly(request):
    user=facultyregister.objects.all()
    return render(request,"delfly.html",{'result':user})

# def flyedit(request):
#     return render(request,'flyedit.html')

# def flyedit(request):
#     user=facultyregister.objects.all()
#     return render(request,'flyedit.html',{'result':user})

# def editflyform(request):
#     saver=facultyregister.objects.all()
#     return render(request,'editflyform.html',{'result':saver})

# def update(request,id):
#     user=facultyregister.objects.all()
#     return render(request,'editflyform.html',{'result':user})

# def updates(request,id):
#     if request.method=="POST":
#         designation=request.POST.get('designation')
#         fullname=request.POST.get('name')
#         mailid=request.POST.get('email')
#         passwords=request.POST.get('password')
#         regestration=facultyregister(designation=designation,email=mailid,name=fullname,password=passwords,id=id)
#         regestration.save()
#     return redirect (editflyform)




def deletea(request,id):
    members=facultyregister.objects.get(id=id)
    members.delete()
    return redirect(delfly)

def acknowledgementtostd(request):
    return render(request,'acknowledgementtostd.html')



def acknowledgementtostd(request):
    if request.method=="POST":
        name=request.POST.get('name')
        date=request.POST.get('date')
        email=request.POST.get('email')
        fromemail=request.POST.get('fromemail')
        ackmesg=request.POST.get('ackmesg')
        regestration=acknowledgement(name=name,date=date,email=email,fromemail=fromemail,ackmesg=ackmesg)
        regestration.save()
    return render(request,'acknowledgementtostd.html',{'sucess':'RegisteredSusessfully'})


def profilestd(request):
    tem=request.session['uid']
    vpro=studentregister.objects.get(id=tem)
    return render(request,'profilestd.html',{'result':vpro})

def profilefly(request):
    tem=request.session['vid']
    vpro=facultyregister.objects.get(id=tem)
    return render(request,'profilefly.html',{'result':vpro})

def profileadmin(request):
    tem=request.session['admin']
    return render(request,'profileadmin.html',{'result':tem})

def statusedit(request):
    return render (request,'statusedit.html')

def statusedit(request):
    temp=request.session['email']
    user=complaint.objects.filter(complaintto=temp)
    return render(request,'statusedit.html',{'result':user})

def statuseditform (request):
    return render (request,'statuseditform.html')


def updatec(request,id):
    saver=complaint.objects.get(id=id)
    return render(request,'statuseditform.html',{'result':saver})

def updatesc(request,id): 
    
    if request.method=="POST":
        userid=request.POST.get('userid')
        complaintto=request.POST.get('complaintto')
        date=request.POST.get('date')
        name=request.POST.get('name')
        email=request.POST.get('email')
        complaintmesg=request.POST.get('complaintmesg')
        status=request.POST.get('status')
        user_id=request.POST.get('user_id')
        regestration=complaint(userid=userid,complaintto=complaintto,date=date,name=name,email=email,complaintmesg=complaintmesg,status=status,user_id=user_id,id=id)
        regestration.save()
    return redirect(statusedit)

def delete(request,id):
    members=complaint.objects.get(id=id)
    members.delete()
    return redirect(statusedit)

def flyedit(request):
    return render (request,'flyedit.html')

def flyedit(request):
    user=facultyregister.objects.all()
    return render(request,'flyedit.html',{'result':user})

def editflyform (request):
    return render (request,'editflyform.html')


def updateb(request,id):
    saver=facultyregister.objects.get(id=id)
    return render(request,'editflyform.html',{'result':saver})

def updatesb(request,id): 
    if request.method=="POST":
        designation=request.POST.get('designation')
        fullname=request.POST.get('name')
        mailid=request.POST.get('email')
        passwords=request.POST.get('password')
        regestration=facultyregister(designation=designation,email=mailid,name=fullname,password=passwords,id=id)
        regestration.save()
    return redirect(flyedit)

