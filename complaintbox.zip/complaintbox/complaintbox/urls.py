"""
URL configuration for complaintbox project.

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/4.2/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path
from . import views
from django.conf.urls import url
from django.conf import settings
from django.conf.urls.static import static

urlpatterns = [
     path('',views.index),

     path('student_register',views.student_register),

     path('studentaddregister',views.studentaddregister),

     path('faculty_register',views.faculty_register),

     path('facultyaddregister',views.facultyaddregister),

     path('viewstudent',views.viewstudent),

    #  path('viewstd',views.viewstd),

     path('viewfaculty',views.viewfaculty),

    #  path('viewfly',views.viewfly),

     path('login',views.login),

     path('complaintstd',views.complaintstd),

     path('complaintview',views.complaintview),

     path('complaintviewa',views.complaintviewa),

     path('complaintviewf',views.complaintviewf),

     path('logout',views.logout),

     path('acknowledgementfly',views.acknowledgementfly),

     path('knowledgefly',views.knowledgefly),

     path('update/<int:id>',views.updatea,name='update'),
     path('update/updates/<int:id>',views.updatesa, name='updates'),

     path('updateb/<int:id>',views.updateb,name='updateb'),
     path('updateb/updatesb/<int:id>',views.updatesb, name='updatesb'),

     path('updatec/<int:id>',views.updatec,name='updatec'),
     path('updatec/updatesc/<int:id>',views.updatesc, name='updatesc'),

     path('deletes/<int:id>',views.deletes, name='deletes'),

     path('deletea/<int:id>',views.deletea, name='deletea'),

     path('delete/<int:id>',views.delete, name='delete'),

     path('delete/<int:id>',views.delete, name='delete'),

     path('acknowledgementtostd',views.acknowledgementtostd),

    #  path('acktostd',views.acktostd),

     path('viewstdknowledge',views.viewstdknowledge),

     path('viewstdknowledges',views.viewstdknowledges),

    #  path('viewstdknowledge',views.viewstdack),

     path('admintofly',views.admintofly),

     path('acktofly',views.acktofly),

     path('viewflyknowledge',views.viewflyknowledge),

     path('viewflyknowledgea',views.viewflyknowledgea),

    #  path('viewflyack',views.viewflyack),

     path("delstd",views.delstd),

     path("editstdform",views.editstdform),

     path('stdedit',views.stdedit),

     path("delfly",views.delfly),

     path("editflyform",views.editflyform),

     path('flyedit',views.flyedit),

    #  path('addlogin',views.addlogin),

    path('profilestd',views.profilestd),

    path('profilefly',views.profilefly),

    path('profileadmin',views.profileadmin),

    path("statuseditform",views.statuseditform),

    path("statusedit",views.statusedit),
    
]+ static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
